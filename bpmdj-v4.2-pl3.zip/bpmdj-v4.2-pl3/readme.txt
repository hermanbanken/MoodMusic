BpmDj turns your Linux machine (or cluster) into a DJ system. BpmDj
plays Mp3's/Ogg's, provides a fully automatic BPM counter, measures
sound color, recognizes similar rhythms and compositions. Aside from
music analysis, it also provides the meat each DJ looks for: a full
fledged QT interface, that will help you navigate your music
collection. The BpmDj player matches tempos automatically. Its unique
visualization method, (beatgraphs) helps you to understand the songs
structure at a glance.

Probably, you will need to compile the package yourself. To do so, read 
compile.txt. If you encounter any difficulties please contact me
through the forum at http://bpmdj.yellowcouch.org/forum/

A manual is online at http://bpmdj.yellowcouch.org/

Werner,-

--
werner@yellowcouch.org
http://werner.yellowcouch.org/
